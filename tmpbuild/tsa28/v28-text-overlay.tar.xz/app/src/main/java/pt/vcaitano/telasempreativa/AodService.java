package pt.vcaitano.telasempreativa;

import android.app.KeyguardManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

public class AodService extends Service {
    static final String ACTION_CLOSE_AOD = "pt.vcaitano.telasempreativa.CLOSE_AOD";
    private static final String CHANNEL_ID = "aod_service";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private static final long SCREEN_OFF_STABLE_MS = 1200L;
    private static final long LOCK_SCREEN_WAKE_WINDOW_MS = 3000L;
    private int lockAttempts;
    private long screenOffAt;
    private WindowManager windowManager;
    private View overlayAnchor;

    private final Runnable openWhenLocked = new Runnable() {
        @Override
        public void run() {
            if (!Prefs.get(AodService.this).getBoolean(Prefs.AOD_ENABLED, true)) return;
            if (!readyForAod()) {
                if (lockAttempts++ < 40) handler.postDelayed(this, 250L);
                return;
            }
            openAod();
        }
    };

    private final BroadcastReceiver screenReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null) return;
            String action = intent.getAction();
            if (Intent.ACTION_SCREEN_OFF.equals(action)) {
                scheduleOpen();
            } else if (Intent.ACTION_SCREEN_ON.equals(action)) {
                // Alguns aparelhos reacendem a própria tela de bloqueio logo depois do
                // ACTION_SCREEN_OFF. Não cancelamos a AOD nessa transição curta se o
                // keyguard já estiver ativo. Um SCREEN_ON normal continua cancelando.
                long sinceScreenOff = screenOffAt <= 0L ? Long.MAX_VALUE
                        : android.os.SystemClock.elapsedRealtime() - screenOffAt;
                if (sinceScreenOff <= LOCK_SCREEN_WAKE_WINDOW_MS && isLocked()) {
                    handler.removeCallbacks(openWhenLocked);
                    handler.postDelayed(() -> {
                        if (Prefs.get(AodService.this).getBoolean(Prefs.AOD_ENABLED, true)
                                && isLocked() && !AodActivity.isOpen()) {
                            openAod();
                        }
                    }, 120L);
                } else {
                    handler.removeCallbacks(openWhenLocked);
                }
            } else if (Intent.ACTION_USER_PRESENT.equals(action)) {
                handler.removeCallbacks(openWhenLocked);
                KeyguardManager manager = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
                if (manager == null || manager.isDeviceSecure()) {
                    sendBroadcast(new Intent(ACTION_CLOSE_AOD).setPackage(getPackageName()));
                }
            } else if (PowerManager.ACTION_POWER_SAVE_MODE_CHANGED.equals(action) && powerSaveMode()) {
                handler.removeCallbacks(openWhenLocked);
                sendBroadcast(new Intent(ACTION_CLOSE_AOD).setPackage(getPackageName()));
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        createForegroundNotification();
        createOverlayAnchor();
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        filter.addAction(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_USER_PRESENT);
        filter.addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenReceiver, filter, Context.RECEIVER_EXPORTED);
        else registerReceiver(screenReceiver, filter);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!Prefs.get(this).getBoolean(Prefs.AOD_ENABLED, true)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        createOverlayAnchor();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        try { unregisterReceiver(screenReceiver); } catch (Exception ignored) {}
        removeOverlayAnchor();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private void scheduleOpen() {
        handler.removeCallbacks(openWhenLocked);
        lockAttempts = 0;
        screenOffAt = android.os.SystemClock.elapsedRealtime();
        handler.postDelayed(openWhenLocked, 350L);
    }

    private boolean isLocked() {
        KeyguardManager manager = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        return manager != null && (manager.isDeviceLocked() || manager.isKeyguardLocked());
    }

    private boolean screenIsActuallyOff() {
        PowerManager manager = (PowerManager) getSystemService(POWER_SERVICE);
        return manager != null && !manager.isInteractive();
    }

    private boolean readyForAod() {
        if (!screenIsActuallyOff()) return false;
        if (android.os.SystemClock.elapsedRealtime() - screenOffAt < SCREEN_OFF_STABLE_MS) return false;

        KeyguardManager manager = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        if (manager == null) return true;

        boolean keyguardLocked = manager.isDeviceLocked() || manager.isKeyguardLocked();
        if (keyguardLocked) return true;

        // Devices without a secure lock may never report a locked keyguard.
        // In that case, a stably non-interactive screen is enough.
        return !manager.isDeviceSecure();
    }

    private boolean powerSaveMode() {
        PowerManager manager = (PowerManager) getSystemService(POWER_SERVICE);
        return manager != null && manager.isPowerSaveMode();
    }

    private void openAod() {
        if (powerSaveMode() || AodActivity.isOpen()) return;
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Log.w("TelaSempreAtiva", "AOD não aberta: permissão de sobreposição ausente");
            return;
        }
        Intent intent = new Intent(this, AodActivity.class)
                .putExtra(AodActivity.EXTRA_PREVIEW, false)
                .putExtra(AodActivity.EXTRA_REAL_AOD_AUTHORIZED, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
                        | Intent.FLAG_ACTIVITY_NO_ANIMATION
                        | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        try {
            startActivity(intent);
        } catch (Exception error) {
            Log.w("TelaSempreAtiva", "Não foi possível abrir a AOD", error);
        }
    }

    private void createOverlayAnchor() {
        if (overlayAnchor != null || Build.VERSION.SDK_INT < 26 || !Settings.canDrawOverlays(this)) return;
        try {
            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            overlayAnchor = new View(this);
            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            params.gravity = Gravity.TOP | Gravity.START;
            params.alpha = .01f;
            windowManager.addView(overlayAnchor, params);
        } catch (Exception error) {
            overlayAnchor = null;
            Log.w("TelaSempreAtiva", "Não foi possível criar a camada de sobreposição", error);
        }
    }

    private void removeOverlayAnchor() {
        if (windowManager != null && overlayAnchor != null) {
            try { windowManager.removeView(overlayAnchor); } catch (Exception ignored) {}
        }
        overlayAnchor = null;
        windowManager = null;
    }

    private void createForegroundNotification() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                getString(R.string.aod_service_channel), NotificationManager.IMPORTANCE_LOW);
        channel.setDescription(getString(R.string.aod_service_text));
        channel.setShowBadge(false);
        manager.createNotificationChannel(channel);
        Intent settingsIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, settingsIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification notification = new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle(getString(R.string.aod_service_title))
                .setContentText(getString(R.string.aod_service_text))
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .build();
        startForeground(1, notification);
    }

    static void sync(Context context) {
        Prefs.seed(context);
        Intent service = new Intent(context, AodService.class);
        if (Prefs.get(context).getBoolean(Prefs.AOD_ENABLED, true)) {
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(service);
            else context.startService(service);
        } else {
            context.stopService(service);
        }
    }
}
